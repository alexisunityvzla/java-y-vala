package bnota{

    public bnota{

        public static void Main(string [] args){
            Scanner sc = new Scanner(System.in);
            int nota;
            System.out.println("instroduzca una nota:");
            nota =int  sc.nextInt();

            if(nota>=0 && nota<5){

                System.out.println("INSUFICIENTE");
            }
            else{

                if(nota == 5){

                    System.out.println("SUFICIENTE");

                    else{

                        if(nota == 6){

                            System.out.println("BIEN");

                            else{

                                if( nota == 7 || nota == 8){

                                    System.out.println("NOTABLE");

                                    else{

                                        if(nota == 9 || nota == 10){

                                            System.out.println("SOBRESALIENTE");
                                        }
                                    }

                                }
                            }
                        }
                    }
                }
            }

                System.out.println("finalizar");
        }
    }
}