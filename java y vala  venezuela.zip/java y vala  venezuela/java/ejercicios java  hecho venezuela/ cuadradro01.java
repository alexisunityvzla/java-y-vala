package cuadradro01{
	
	public class cuadradro01{

	  public static void Main(string [] args){
	  		BufferedReader bufEntrada = new BufferedReader (Stream Input(System.in));

	  		int num,cuadradro;

	  		System.out.println("instroduzca cuadradro:");
	  		num=bufEntrada.readLine();

	  		while(num >= 0){

	  		  cuadradro = num * num;

	  		  System.out.println(num+"es igual a"+cuadradro);
	  		  System.out.println("instroduzca un numero:");
	  		  num=bufEntrada.readLine();
	  		}
	  }
	}
}