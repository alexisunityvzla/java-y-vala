package programa{
	
	public class programa{

	    public static void Main(string [] args){

	      BufferedReader bufEntrada = new BuffereadReader(input stream(System.in));

	      	int opcion=0;
	      	string java;
	      	string Ruby;
	      	while(opcion != 2){
	      	  System.out.println("instroduzca los programa de java o Ruby en basado en objeto:");
	      	  System.out.println("n1.java");
	      	  System.out.println("n2.Ruby");
	      	  System.out.println("salir");
	      	  opcion=bufEntrada.readLine();

	      	    switch(opcion){

	      	      case 1: System.out.println("elige su color favoritos n java:");

	      	       java=bufEntrada.readLine();

	      	       System.out.println("el color de java es:"+java); break:

	      	       case 2: System.out.println("elige el objeto reconocido en Ruby o el aspecto mas mas famoso:");

	      	        Ruby=bufEntrada.readLine();

	      	        System.out.println("el objeto favorito es:"+Ruby); break;

	      	        case 3:default: System.out.println("se equivoco de oco de opcion"): break;
	      	    }
	      	}



	    }
	}
}