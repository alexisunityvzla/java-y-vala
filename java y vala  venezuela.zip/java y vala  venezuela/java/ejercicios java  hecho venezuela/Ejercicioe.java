/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicioe;

import java.util.Scanner;

/**
 *
 * @author alexis094
 */
public class Ejercicioe {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner sc = new Scanner(System.in);
        double l,r = 0;
        int opcion = 0;
        
        System.out.println("digite la esfera completa:");
        System.out.println("selecciona la longitud:");
        
        l= sc.nextDouble();
        switch(opcion){
            case 1: default: System.out.println("selecciona el radio:");
            r=sc.nextDouble();
            do{
            
            System.out.println("para calcular la esfera es:");
            
            }while(l>=2);
            
        
            case 2 : System.out.println("el resultado final d la esfera es:");
                    System.out.println("la longitud:"+l);
                    System.out.println("el radio:"+r);
                    System.out.println("finalizar");
        }
        
    }
    
}
