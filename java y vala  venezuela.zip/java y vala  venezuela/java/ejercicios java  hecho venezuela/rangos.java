package rangos{

    public class rangos{

        public static void Main(string [] args){
            Scanner sc = new Scanner(System.in);

            int num;
            System.out.println("instroduzca una nota numerica entre 0 y 99:");
            num = sc.nextInt();
                unidades = num % 10;
                decenas = num / 10;
            switch(decenas){
                case 0: System.out.println(""); break;

                case 1: System.out.println("diez"); break;

                case 2: System.out.println("veintes"); break;

                case 3: System.out.println("treintas"); break;

                case 4: System.out.println("cuarentas"); break;

                case 5: System.out.println("cicuentas"); break;

                case 6: System.out.println("sesentas"); break;

                case 7: System.out.println("sesenta"); break;

                case 8: System.out.println("ochentas"); break;

                case 9: System.out.println("noventas"); break;

            }
            System.out.println("y");

            switch(unidades){

                case 0: System.out.println(""); break;

                case 1: System.out.println("uno"); break;

                case 2: System.out.println("dos"); break;

                case 3: System.out.println("tres"); break;

                case 4: System.out.println("cuatro"); break;

                case 5: System.out.println("cinco"); break;

                case 6: System.out.println("seis"); break;

                case 7: System.out.println("siete"); break;

                case 8: System.out.println("ocho"); break;

                case 9: System.out.println("nueve"); break;
            }

        }
    }
}