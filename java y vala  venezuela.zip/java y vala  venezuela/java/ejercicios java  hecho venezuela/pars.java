package par{

    public class par{

        public static void Main(String [] args){
            Scanner sc = new Scanner(System.in);

            int num;
            while(num != 0){
                System.out,println("instroduzca un numero:");

                num = sc.nextInt();

                if(num >= 0){

                    System.out.println("es par");
                }
                else{
                    System.out.println("es impar");
                }

            }
            System.out.println("instroduzca otro numero:");

            num = sc.nextInt();


        }
    }
}