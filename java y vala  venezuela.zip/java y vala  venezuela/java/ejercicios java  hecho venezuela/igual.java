package igual{

    public class igual{

        public static void Main(string [] args){

            int n1,n2;
            n1=Entrada.entero("introduce un numero:");
            n2=Entrada.entero("introduce otro numero:");

            if(n1==n2){

                System.out.println("son iguales");
            }
            else{
                System.out.println("no son iguales");
            }
        }
    }
}