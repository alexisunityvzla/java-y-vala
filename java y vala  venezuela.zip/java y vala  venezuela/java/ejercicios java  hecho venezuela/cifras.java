package cifras{

    public class cifras{

        public static void Main(string [] args){
		Scanner = new Scanner(System.in);
            int num;

            num=sc.nextInt("instroduzca un numero entre 0 y 99.999:");

            if(num<10){

            System.out.println("el tiene 1 cifras");
            }
            else{
                if(num<100)
                System.out.println("el tiene 2 cifras");

                else{
                    if(num<1000)
                    System.out.println("el tiene 3 cifras");

                    else{
                        if(num<10000)

                        System.out.println(el tiene 4 cifras");

                        else{
                            if(num<100000)

                            System.out.println("el tiene 5 cifras");
                        }
                    }
                }
            }
        }
    }
}