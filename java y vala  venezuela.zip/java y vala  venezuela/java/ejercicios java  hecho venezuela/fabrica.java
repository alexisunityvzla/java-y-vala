package fabrica{

    public int[] obtenArray(){

        int array[]={1,2,3,4,5};

        return array;
    }

    public class returnArray{
        public static void main(string args []){
            fabricaArrays fab=new fabricaArrays ();
            int nuevoArray []=fab.obtenArray();

            System.out.println("resultado es:"+nuevoArray);

        }

    }
}