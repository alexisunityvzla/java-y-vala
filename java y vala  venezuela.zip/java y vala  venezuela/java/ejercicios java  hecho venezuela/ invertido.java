package invertido{
	
	public class invertido{
		
	

	  	public static void Main(string [] args){
	  		Scanner sc=new Scanner(System.in);

	    	int n1,n2;
	    	int rev1,rev2;

	    	System.out.println("primer numero:");
	    	n1=sc.nextInt();
	    	System.out.println("segundo numero:");
	    	n2=sc.nextInt();
	    	System.out.println("tercer numero:");
	    	rev1=sc.nextInt();
	    	System.out.println("cuarto numero:");
	    	rev2=sc.nextInt();

	    	rev1=n1/10;
	    	rev1=n1%10;
	    	rev2=n2/10;
	    	rev2=n2%10;

	    	System.out.println("primer numero es:"+n1);
	    	System.out.println("segundo numero es:"+n2);
	    	System.out.println("tercer numero es:"+rev1);
	    	System.out.println("cuarto numero es:"+rev2);
	    	System.out.printl("finalizar");



	    }
	}
}