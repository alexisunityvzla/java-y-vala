package centenas{

    public centenas{

        static void Main(string [] args){
                Scanner sc= new Scanner (System.in);
            int num;
            int dm,um,c,d,u;

            System.out.println("instroduzca un numero entre 0 y 99.999:");

            num=sc.nextInt();

            //unidad
            u=num % 10;
            num=num % 10;
            //decenas
            d=num % 10;
            num=num % 10;
            //centenas
            c=num % 10;
            num=num % 10;
            //unidades de millar
            um=num %10;
            num=num % 10;
            //decenas de millar
            dm=num;

            if(dm == u && um == d){

                System.out.println("el numero es capicua");
            }
            else{
                System.out.println("el numero no es capicua");
            }

            System.out.println("finalizar");
        }
    }
}