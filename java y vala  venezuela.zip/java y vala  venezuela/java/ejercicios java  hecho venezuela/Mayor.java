/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mayor;

import java.util.Scanner;

/**
 *
 * @author alexis094
 */
public class Mayor {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner sc = new Scanner(System.in);
         
        int a,b,c;
        System.out.println("instroduzca un numero:");
        a= sc.nextInt();
        System.out.println("instroduzca otro numero:");
        b=sc.nextInt();
        System.out.println("instroduzca el ultimo numero:");
        c=sc.nextInt();
        
        if(a>b && b>c){
        System.out.println(a+""+b+""+c);
        }
        else{
              if(a>c && c>b) 
             System.out.println(a+""+c+""+b);
            }
        
        System.out.println("el numero mayor es:"+a);
        System.out.println("el numero mayor es:"+b);
        System.out.println("el numero mayor es:"+c);
        System.out.println("finalizar");
    }
    
}
