package bono{

    public class bono{
        
        public static void Main(string [] args){
         Scanner sc = new Scanner(System.in);

         double sueldo,arecibir;
         int nhijo,bono,nom;

         System.out.println("nombres del empleados:");
         nom=sc.nextInt();
         System.out.println("sueldos del empleados:");
         sueldo=sc.double();
         System.out.println("numeros de hijos:");
         nhijo=sc.nextInt();
            if(nhijo >= 3){
             bono=nhijo * 10;
            }
            else{
             bono=nhijo * 20;
            }
            arecibir=sueldo + bono;
            System.out.println("recibe:"+arecibir);
            System.out.println("Pulsa la tecla");
        }
    }
}