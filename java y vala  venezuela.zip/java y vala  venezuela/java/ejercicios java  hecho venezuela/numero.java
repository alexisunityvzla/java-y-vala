package numero{

    public class numero{

        public void main(string args[]){
		Scanner = new Scanner(System.in);
            int n1,n2;
            
            System.out.pritnln("selecciona un numero:");
            n1=sc.nextInt();
            System.out.println("selecciona otro numero:");
            n2=sc.nextInt();
            System.out.println("el resultado seria:"+n1+n2);
        }
    }
}