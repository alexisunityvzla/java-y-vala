/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package radio;

import java.util.Scanner;

/**
 *
 * @author alexis094
 */
public class Radio {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner sc = new Scanner(System.in);
        double l,r;
        System.out.println("introduce el radio de una circuferencia:");
        r=sc.nextDouble();
        
        
        l=2*Math.PI*r;
        System.out.println("la longitud de una circuferencia de radio:"+l);
        
    }
    
}
