package vehiculo{

    public class vehivulo{

        int ruedas;
        private double velocidad=0;
        string nombre;
        public void acelerar(double cantidad){
            velocidad += cantidad;
        }
        public void  frenar(double cantidad){
            velocidad -= cantidad;
        }
        public double obtenervelocidad(){
            return velocidad;
        }

        public static void main(string args[]){
            vehiculo miCoche = new vehiculo();
            miCoche.acelerar(12);
            miCoche.frenar(5);
            System.out.println(miCoche.obtenervelocidad());
        }
    }
}