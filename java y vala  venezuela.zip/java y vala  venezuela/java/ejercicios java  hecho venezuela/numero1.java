package numero{

    public class numero{

        public static void Main(string [] args){
            Scanner = new Scanner (System.in);


            int num1,num2;
            double RESUL;

            System.out.println("numero 1:");
            num1 = sc.nextINT();
            System.out.println("numero 2:");
            num2 = sc.nextINT();

            RESUL = (num1+num2)*(num1-num2);

            System.out.println("");
            System.out.println("el resutado es:"+RESUL);
            System.out.println("finalizar");
        }
    }
}