package cuadradro{

    public class cuadradro{

        public static void Main(string [] args){
            Scanner sc = new Scanner(System.in);

            int num,cuadradro;
            System.out.println("instroduzca un numero:")

            num = sc.nextInt();
            while(num >= 0){

                System.out.println(num+"es igual a"+cuadradro);
                System.out.println("instroduzca otro numero:");

                num = sc.nextInt();
            }
        }
    }
}
