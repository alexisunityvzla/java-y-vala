package piramide{
	
	public class piramide{

	   	public class Main void(string [] args){

	   	  Scanner sc=new scanner(System.in);

	   	  double p3,a2;
	   	  do{
	   	   		System.out.println("selecciona la altura de la piramide:");
	   	   		p3 =double sc.next();
	   	   		System.out.println("selecciona la anchura de la piramide:");
	   	   		a2 = double sc.next();

	   	  	}while(p3 > 2);

	   	  	System.out.println("la altura es:"+p3);
	   	  	System.out.println("la anchura es:"+a2);
	   	  	System.out.println("finalizar");


	}
	  }
}