/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bladearcus;

import java.util.Scanner;

/**
 *
 * @author alexis094
 */
public class Bladearcus {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner sc = new Scanner(System.in);
        int a;
        System.out.println("elge tu personajes favoritos:");
        System.out.println("Bladearcus:");
        
        a = sc.nextInt();
        switch(a){
        
            case 1: System.out.println("es pairon"); break;
            case 2:  System.out.println("es mystic"); break;
            case 3: System.out.println("es sakuya"); break;
            case 4: System.out.println("es sonia"); break;
            case 5:  System.out.println("urayukihime"); break;
            case 6: default: System.out.println("usted a equivocado de personajes elige de nuevo"); break;
        }
    }
    
}
