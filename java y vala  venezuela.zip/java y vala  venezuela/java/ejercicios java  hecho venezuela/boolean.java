package boolean{


public class boolean{

     public static void Main(string [] args){

        Scanner sc = new Scanner (System.in);

        int num;
        int dm,um,c,d,u;

        boolean capicua = false;

        System.out.println("instroduzca un numero:);

        num=int sc.nextInt();

        //unidad
        u = num % 10;
        num = num/10; 

        //decenas

        d = num % 10;
        num = num / 10;

        //centenas
        c = num % 10;
        num = num / 10;

        //unidades de millar

        um = num % 10;
        num = num / 10;

        //decenas de millar

        dm = num;

        if(dm == 0 && um == d)
            capicua = true;

        if(dm == 0 && um == u && c == d)
          capicua = true;

        if(dm == 0 && um == 0 && c == u)

          capicua = true;

        if(dm == 0 && um == 0 && c == 0 && d ==u)

          capicua = true;

        if(capicua){


        System.out.println("el numero es capicua");
        }
        else{
            Systemm.out.println("el numero no es capicua");
        }
        System.out.println("finalizar");

        

    }
}


}