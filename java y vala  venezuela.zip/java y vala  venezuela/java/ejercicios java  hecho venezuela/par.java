package par{

    public class par{

        public static void main(string args []){
            Scanner = new Scanner(System.in);
            double n1;
            System.out.println("compara si es un numero impar o par);

            n1=sc.nextdouble();
            if(n1&2==0){

                System.out.println("es par");
            }
            else{
                System.out.println("es impar");
            }
        }
    }
}