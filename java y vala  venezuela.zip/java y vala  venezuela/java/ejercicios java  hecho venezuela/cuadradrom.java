package consenos{

    public class consenos{

        public static void Main(string [] args){
            Scanner sc=new Scanner(System.in);

            double n1.p,r;
            System.out.println("ingrese un numero:");
            n1=sc.nextDouble();
            System.out.println("elevalo a la potencia:");
            p=sc.nextDouble();
            r=Math.Pow(p1,r)
            System.out.println("resultado:"+r);
            System.out.println("finalizar");
        }
    }
}