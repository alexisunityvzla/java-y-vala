package circulo{

    public class circulo{

        public static void main (string []  args){
		Scanner= new Scanner(System.in);
            r=sc.nextint("introduce radio de un circulo:");

            a=Math.PI*(r*r);

            System.out.println("el area de una circuferencia de radio"+r+"es:"+a);
        }
    }
}