package ciclo{

    public class ciclo{

        public static void main(string [] args ){
		Scanner = new Scanner(System.in);
            int p2,n1,p4;
            for(p2=0;p2<=2;p2++){
             System.out.println("selecciona un numero:");
             p2=sc.nextInt();

            }
            for(n1=1;n1<=2;n1++){
             System.out.println("selecciona otro numero:");
             n1=sc.nextInt();
            }
            for(p4=2;p4<=4;p4++){

                System.out.println("selecciona el ultimo:");
                p4=sc.nextInt();
            }

            System.out.println("el resultado seria:"+p2+p4+n1);
            System.out.println("finalizado");
        }
    }
}