package  num{

    public class num{

        public static void Main(string [] args){
		Scanner = new Scanner(System.in); 
            int num;

            num=sc.nextInt("digite un numero:");

            if(num<0){

                System.out.println("negativo");
            }
            else{

                System.out.println("positivo");
            }
        }
    }
}