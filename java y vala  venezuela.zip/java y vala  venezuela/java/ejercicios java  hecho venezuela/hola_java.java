package java;

    public  hola{



        public static void main(String [] args){
	
            system.out.println("hola_java");
		
            
        }
    }                  

