package multiplos100{
	
	public class multiplos100{

	    public static void Main(string [] args){
	    	Scanner sc=new Scanner(System.in);
	     	int n,h;

	     	h=1;
	     	n=1;

	     	while(n >= 2){

	       		System.out.println(n);



	     	 h+=1;
	     	 n+=1;

	     	}

	     	System.out.println("entre multiplos 1 y 100  hay %i  de multiplos 3:");
	     	System.out.println("finalizar");


	    }
	}
}