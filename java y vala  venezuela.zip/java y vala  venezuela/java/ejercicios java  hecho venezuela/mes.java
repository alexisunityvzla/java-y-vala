package rango{

    public class rango{

        public static void Main(string [] args){
            Scanner sc= new Scanner(System.in);
            int dia,mes,año;

            System.out.println("instroduzca dia:");
            dia = sc.nextINT();
            System.out.println("instroduzca mes:"); 
            mes = sc.nextINT();
            System.out.println("instroduzca año:");
            año = sc.nextINT();

            if(dia >= 1 && dia <= 30){
                if(mes >= 1 && mes <= 30){
                    if(años != 0){
                        System.out.println("fecha correcta");
                    }(
                    else{
                        System.out.println("año incorrecto");
                    }
                    else{
                        System.out.println("mes incorrecto");
                    }
                    else{
                        System.out.println("dia incorrecto");
                    }
                

                

                }
            }

        }
    }
}