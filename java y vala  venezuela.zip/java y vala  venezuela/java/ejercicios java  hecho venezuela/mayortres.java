package mayor{

    public class mayor{

        public static void Main(string [] args){
		Scanner = new Scanner(System.in);
            int a,b,c;

            a=sc.nextInt("instroduzca un numero:");
            b=sc.nextInt("instroduzca otro numero:");
            c=sc.nextInt("instroduzca el ultimo numero:");

            if(a>b && b>c){

          

            System.out.println(a+","+b+","+c);
            
            else if(a>c && c>b)
            System.out.println(a+","+c+","+b);
            else if(b>c && a>c)

               System.out.println(b+","+a+","+c);

               else
                if(c>a && b>c)

                System.out.println(c+","+b+","+a);

                
            
        }
    }
}
