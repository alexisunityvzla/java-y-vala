/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ficha;





/**
 *
 * @author alexis094
 */
public class Ficha {
        private int casilla ;
        Ficha(){
        casilla();
        }
        public void avanzar (int n){
        casilla += n;
        }
        public int casillaActual(){
        
        return casilla;
        }
 
     public static void main(String[] args){
        // TODO code application logic here
        
        ficha ficha1 = new ficha();
        ficha1.avanzar(3);
        System.out.println(ficha1.casillActual());
        
    }

    private void casilla() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
   }


