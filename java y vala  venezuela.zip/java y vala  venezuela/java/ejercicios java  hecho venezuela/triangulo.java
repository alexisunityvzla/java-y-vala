package triangulo{

    public class triangulo{

        public static void main(string args []){
		Scanner = new Scanner(System.in);
            float base,altura,ancho;
            
            System.out.println("digite la forma del triangulo:");
            System.out.println("selecciona la base:");
            base=sc.nextfloat();
            System.out.println("selecciona la altura:");
            altura=sc.nextfloat();
            System.out.println("selecciona el ancho:");
            ancho=sc.nextfloat();

            base=altura+ancho;
            base=altura-ancho;
            base=altura*ancho;

            System.out.println("el resultado de la base es:"+base*4);
            System.out.println("el resultado de la altura es:"+altura*2);
            System.out.println("el resultado del ancho es:"+ancho*4);
            System.out.println("finalizar");
            

        }
    }
}