package clasificacion{
	
	public class clasificacion{

	   public static void Main(string [] args)	

	      BufferedReader bufEntranda =  new BufferedReader(new InputStreamReader(System.in));
	      Scanner = new Scanner (System.in);

	      string nombre, casado;
	      int cedula,edad;

	      System.out.println("ingrese su nombre:");
	      nombre=bufEntrada.readLine();
	      System.out.println("ingrese su edad:");
	      edad=sc.nextInt();
	      System.out.println("ingrese su cedula:");
	      cedula=sc.nextInt();
	      System.out.pritntln("ingrese casado (s/n):");
	      casado=bufEntrada.readLine();

	      System.out.println("nombre es:"+nombre);
	      System.out.println("edad es:"+edad);
	      System.out.println("cedula es:"+cedula);
	      System.out.println("casado es:"+casado);
	      System.out.println("finalizar");



	   }
}