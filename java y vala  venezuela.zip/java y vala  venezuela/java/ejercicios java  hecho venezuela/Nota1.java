/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nota1;

import java.util.Scanner;

/**
 *
 * @author alexis094
 */
public class Nota1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner sc = new Scanner(System.in);
        
        float nota,nota1;
        System.out.println("digite la nota de los estudiante:");
        System.out.println("si es excelente o regular:");
        
        nota=sc.nextFloat();
        nota1=sc.nextFloat();
        
        if(nota>12.09){
        
        System.out.println("el estudiante es excelente:"+nota);
        }
        else{
        System.out.println("el estudiante es regular:"+nota);
        }
        if(nota<09.09){
        System.out.println("el estudiante es pesimo: "+nota);
        }
        else{
        System.out.println("el estudinte es malo:"+nota);
        }
        System.out.println("la nota total es:"+nota/12.09);
        System.out.println("finalizar");
    }
    
}
