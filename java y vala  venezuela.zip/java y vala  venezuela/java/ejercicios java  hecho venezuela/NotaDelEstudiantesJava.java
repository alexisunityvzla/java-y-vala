
package nota.del.estudiantes.java;


public class NotaDelEstudiantesJava {

    
    public static void main(String[] args) {
    int n;
    System.out.println("notas del estudiantes");
    switch(n){
        case 20:case 19: case 18:
            System.out.println("excelente");
            break;
        case 17: case 16: case 15:
            System.out.println("regular");
            break;
        case 14: case 13: case 12:
            System.out.println("debe estudiar");
           break;
           default:
               System.out.println("no aprobo");
    }
        
    }
    
}
