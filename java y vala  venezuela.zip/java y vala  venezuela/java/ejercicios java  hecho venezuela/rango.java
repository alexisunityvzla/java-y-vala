package rango{

    public class rango{

        public static void Main(string [] args){
            Scanner sc = new Scanner (System.in);
            int num;
            System.out.println("instriduzca una numerica entre 0 y 10:");
            num =sc.nextInt();
            switch(num){

                case 0: System.out.println("cero"); break;

                case 1: System.out.println("uno"); break;

                case 2: System.out.println("dos"); break;

                case 3: System.out.println("tres");break;

                case 4:System.out.println("cuatros"); break;

                case 5: System.out.println("cincos"); break;

                case 6: System.out.println("seis"); break;

                case 7: System.out.println("sietes"); break;

                case 8: System.out.println("ochos"); break;

                case 9: System.out.println("nueves"); break;

                case 10:System.out.println("diez"); break; 
            }

        }
    }
}