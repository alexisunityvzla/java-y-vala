/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package triangulo;

import java.util.Scanner;

/**
 *
 * @author alexis094
 */
public class Triangulo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner  sc= new Scanner(System.in);
        
        float base,altura,ancho;
        
        System.out.println("selecciona la base del triangulo:");
        base=sc.nextFloat();
        System.out.println("selecciona la altura del triangulo:");
        altura=sc.nextFloat();
        System.out.println("seleciona el ncho ddel triangulo:");
        ancho=sc.nextFloat();
        base=altura*ancho;
        altura=base+ancho;
        ancho=altura+base;
        System.out.println("el total del triangulo es:");
        System.out.println("el total de la base es:"+base);
        System.out.println("el total de la altura es:"+altura);
        System.out.println("el total del ancho es:"+ancho);
        System.out.println("finalizar");
                
    }
    
}
