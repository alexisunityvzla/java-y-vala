package personas{

    public class personas{

        public static void Main(string [] args){
            Scanner sc = new Scanner(System.in);
            int n,x,l,suma;
            float promedio,altura,suma;
            System.out.println("cuantas personas hay:");
            n =sc.nextInt();

            x = l;
            suma = 0;

            while(x <= n){
                System.out.println("Ingrese la altura:");
                altura =sc.nextInt();

                suma = suma + altura;
                x = x +l;
                promedio = suma / n;
            }
            System.out.println("altura promedio:"+promedio);
            System.out.println("finalizar");

        }
    }

}