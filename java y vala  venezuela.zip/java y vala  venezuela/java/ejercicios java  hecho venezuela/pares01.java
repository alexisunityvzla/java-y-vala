package pares{
	
	public class pares{

	  public class static void Main(string [] args){

	    BufferedReader bufEntrada = new BufferedReader (Stream Input(System.in));

	    int num;

	    System.out.println("instroduzca cual es par o impar:");
	    n2=bufEntrada.readLine();

	    while(num != 0){

	       if(num%2==0){

	        System.ot.println("par");
	       }
	       else{

	        System.out.println("impar");
	       }

	       System.out.println("instroduzca un numero:");
	       num=bufEntrada.readLine();
	    }
	  }
	}
}