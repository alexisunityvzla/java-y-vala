package reves{
	
	public class reves{

	  	public static void Main(string [] args){

	  			Scanner sc=new Scanner(System.in);

	  	  int n,c,rpta;

	  	  System.out.println("Ingrese dos numero 2 digitos:");
	  	  n=sc.nextInt();
	  	  rpta=sc.nextInt();

	  	  c=n/10;
	  	  c=n%10;
	  	  rpta=c+10;

	  	  System.out.println("el numero reves es:"+rpta);
	  	  System.out.println("finalizar");

	  	}
	}
}