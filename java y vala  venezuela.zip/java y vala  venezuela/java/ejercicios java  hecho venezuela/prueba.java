package seleccion{

    public class prueba{

        public void metodo1(int [] entero){
            entero[0]=18;
        }
    }

    public static void main(string args []){

        int x[]={24,24};
        prueba miprueba = new prueba();
        prueba.metodo1(x);
        System.out.println(x[0]);
    }
}