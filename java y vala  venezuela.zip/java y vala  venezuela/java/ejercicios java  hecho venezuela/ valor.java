package valor{
	
	public class valor{

		public static void Main(string [] args){

		  int opcion;

		  System.out.prinltn("Ingrese un valor entre 1  y 5:");

		  opcion=sc.nextInt();

		  switch(opcion){

		    	case 1: System.out.println("uno"); break;
		    	case 2: System.out.println("dos"); break;
		    	case 3: System.out.println("tres"); break;
		    	case 4: System.out.println("cuatro"); break;
		    	case 5: System.out.println("cinco"); break;
		    	case 6: default: System.out.println("debe ingresar  un valor compredido entre 1 y 5..");break;	  

		    }


		}

	}
}