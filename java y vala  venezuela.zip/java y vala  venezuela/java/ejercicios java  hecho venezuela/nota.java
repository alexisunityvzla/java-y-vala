package nota{


    public class nota{

        public static void main(string args []){
		Scanner = Scanner(System.in);
            float nota;

            System.out.println("digite la nota de los estudiante:");
            System.out.println("si es excelente o regular:" );

            System.out.println("selecciona nota del estudiante:");
            nota=sc.nextfloat();

            if(nota>12.09){

                System.out.println("el estudiante es excelente:",+nota);
            }
            else{
                System.out.println("el estudiante es regular:",+nota);
            }
            if(nota<09.09){
                System.out.println("el estudiante es pesimo:",+nota);
            }
            else{

                System.out.println("el estudiante es malos:",+nota);
            }

            System.out.println("la nota total es:"+nota/12.09);
            System.out.println("finalizar");
        }
    }
}