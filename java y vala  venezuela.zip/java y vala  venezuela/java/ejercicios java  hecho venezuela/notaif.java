package notaif{

    public notaif{

        public static void Main(string [] args){
            Scanner = new Scanner (System.in);

            double nota1,nota2,nota3;
            double prom;
            System.out.println ("ingrese primera nota:");

            nota1 = sc.nextInt();
            System.out.println("ingrese segunda nota:");

            nota2 = sc.nextInt();

            System.out.println("ingrese tercer nota:");

            nota3 = sc.nextInt();

            prom = (nota1 + nota2 + nota3)/3

            if (prom >= 7){

                System.out.println("promocionado");
            }
             if (prom >= 4){

                 System.out.println("regular");
              }
               else{
                  System.out.println("reprobado");
              }

            System.out.println("finalizar");



        }
    }
}