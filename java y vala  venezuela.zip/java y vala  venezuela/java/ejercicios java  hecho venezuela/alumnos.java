package alumnos{

    public class alumnos{

        public static void Main(string [] args){
            Scanner sc= new Scanner(system.in);

            int const1 = 0;
            int const2 = 0;
            int nota,x,l;

            while(x <= 10 && l <= 10){

                system.out.println("Ingrese la nota:");

                nota=sc.nextInt();
            }
            if(nota <= 7 && nota >= 10){

                const1 = const1 + 1
            }
            else{
                const2 = const2 + 1
            }
            else{
                x = x + l
            }
            system.out.println("Cantidad de alumnos de nota mayores o iguales a 7"+const1);
            system.out.println("Cantidad de alumnos de nota menores a 7"+const2);
            system.out.println("finalizar");
        }
    }
}