package mayor{

    public class mayor{

        public static void Main(string [] args){
	Scanner = new Scanner(System.in);
            int n1,n2;
            
            n1=sc.nextInt("instroduzca un numero:");
            n2=sc.nextInt("instroduzca otro numero:");

            if(n1>n2){

                System.out.println(n1+" es mayor que:"+n2);

            }
            else{
                System.out.println(n2+"es mayor que:"+n1);
            }
        }
    }
}