package trimestre;
	
	public class trimestre{

	  	public class static void Main(string [] args){

	      Scanner sc=new Scanner(System.in);

	      int dd,mm,aa;

	      	System.out.println("Ingrese el nro. dia:");
	      	dd=sc.nextInt();
	      	System.out.println("Ingrese el nro. mes:");
	      	mm=sc.nextInt();
	      	System.out.println("Ingrese el nro. dia:");
	      	aa=sc.nextInt();

	      	if(mm == 1 || mm == 2 || mm == 3){

	      	  System.out.println("Corresponde al primer trimestre");
	      	}

	  	}
	}

