package radio{

    public class radio{

        public static void Main(string [] args){
		Scanner = new Scanner(System.in);
            double l,r;

            r=sc.nextdouble("introduce el radio de una circunferencia:");

            l=2*Math.PI*r;

            System.out.println("la longitud de una circunferencia de radio"+r+"es:"+l);
        }
    }
}