package cuadrado{
	
	public class cuadradro{

	    public static void Main (string [] args){
     		Scanner sc=new Scanner(System.in);
	    	double num;
	    	int res;
	    	System.out.println("ingrese un numero:");
	    	num=sc.nextdouble();
	    	System.out.println("Realizar otra operacion (s/n):");
	    	res=sc.nextInt();
	    	if(res<=5){

	    	 System.out.println("suficiente");
	    	}else{

	    	 System.out.println("no essuficiente");
	    	}


	    }
	}
}