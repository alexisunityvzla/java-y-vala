package  n{
	
	public class n{

	  public static void Main(string [] args){

	    int n;
	    for(n=2;n<=20;n+=5){
	    System.out.println(n);
	    }
	  }
	}
}
