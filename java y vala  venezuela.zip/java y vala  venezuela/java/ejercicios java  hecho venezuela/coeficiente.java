package coeficiente{

    public class coeficiente{

        public static void main (string args []){
		Scanner = new Scanner(System.in);
            double a,b,c;
            double x1,x2,d;

            a=sc.nextdoudble("introduzca primer coeficiente:");
            b=sc.nextdouble("introduzca segundo coeficiente:");
            c=sc.nextdouble("instroduzca tercer coeficiente:");

            d=((b*b)-2*a*c);

            if(d<0){

                System.out.println("no existen soluciones reales");

            }
            else{
                System.out.println("si existen soluciones reales");

            }

            x1=(-b+Math.sqrt(d))/(2*a);
            x2=(-b-Math.sqrt(d))/(2*a);

            System.out.println("solucion:"+x1);
            System.out.println("solucion:"+x2);
        }
    }
}