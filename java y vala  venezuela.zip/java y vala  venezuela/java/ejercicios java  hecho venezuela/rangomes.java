package rango{
	
	public class rango{

	    public static void Main(string [] args){

	       BufferedReader  bufEntrada = new BufferedReader(new Input StreamReader(System.in));

	       System.out.println("instoduzca dia:");
	       dia=bufEntrada.readLine();
	       System.out.println("instroduzca mes:");
	       mes=bufEntrada.readLine();
	       System.out.println("instroduzca año:");
	       ano=bufEntrada.readLine();

	       if(dia >= 1 && dia <= 30){

	         if(mes >= 1 && mes <= 12){


	           if(año != 0){

	           	System.out.println("fecha correcta");

	           }
	           else{
	           	System.out.println("Año incorrecto");
	           }
	         }
	         else{
	         	System.out.println("mes incorrecto");
	         }

	       }
	       else{
	         System.out.println("dia incorrecto");
	       }

	    }
	}
}