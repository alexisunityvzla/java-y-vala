package casilla{

    public class{
        private int casilla;
        ficha(){
            casilla += n;
        }
        pùblic void avanzar (int n){
            casilla += n;
        }
        public int casillaActual(){
            return casilla;
        }

    }
    public class app{
        public static void main(string [] args){
            ficha ficha1 = new ficha();
            ficha1.avanzar(3);
            System.out.println(ficha1.casillaActual());
        }
    }
}