package positivos{

    public class positivos{

        public static void Main(string [] args){
            Scanner sc = new Scanner(System.in);
            int num;
            System.out.println("instroduzca un numero:");

            num = sc.nextInt();
            while(num != 0){

                if(num >= 0)

                System.out.println("positivos");

                else

                System.out.println("negativos");

                System.out.println("instroduzca otro numero:");
                num = sc.nextInt();
            }

        }
    }
}