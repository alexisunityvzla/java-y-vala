package nota{
	
	public class nota{

	  	public static void Main(string [] args){

	  	  int nota;
	  	 char nombre;

	  	 System.out.println("ingrese su nombre: ");
	  	  nombre=sc.getNextChar();

	  	  System.out.println("ingrese su nota:");
	  	  nota=sc.nextInt();


	  	  if(nota >= 4){

	  	    System.out.println(nombre+"esta aprobado con un"+nota);
	  	  }

	  	  System.out.println("finalizar");	  	

	  	}
	}
}