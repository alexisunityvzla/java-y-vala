package cero{
	
	public class  cero{

	    public static void Main(string [] args){

	      BufferedReader bufEntrada = new BufferedReader(Stream Input(System.in));

	      int num;

	      System.out.println("instroduzca un numero:");
	      num=bufEntrada.readLine();

	      	while(num!= 0){

	        	if(num > 0){
	          		System.out.println("Positivo");
	        	}
	        	else{

	         		System.out.println("Negativo");
	        	}

	        	System.out.println("instroduzca un numero:");
	        	num=bufEntrada.readLine();

	      	}
	    }
	}
}