/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cuadraro;

import java.util.Scanner;

/**
 *
 * @author alexis094
 */
public class Cuadraro {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner sc = new Scanner (System.in);
        double ha23 ,vb34 ,hc12 ,vd12;
        int opcion = 0;
        System.out.println("digite cuanto de los lado mide el cuadrado");
        System.out.println("selecciona el horizontal a, del cuadradro:");
        ha23 = sc.nextDouble();
        System.out.println("selecciona el vertical b, del cuadradro:");
        vb34 = sc.nextDouble();
        System.out.println("selecciona el horizontal c, del cuadradro:");
        hc12 = sc.nextDouble();
        System.out.println("selecciona el vertical d, del cuadradro:");
        vd12 = sc.nextDouble();
        
        switch(opcion){
            case 1:default: System.out.println("el  total del cuadradro mide: ");
            
           
            case 2: System.out.println("horizontal A:"+ha23*23);
                   System.out.println("vertical B:"+vb34+98);
                   System.out.println("horizontal C:"+hc12/34);
                   System.out.println("vertical D:"+vd12);break;
        
        }
    }
    
}
