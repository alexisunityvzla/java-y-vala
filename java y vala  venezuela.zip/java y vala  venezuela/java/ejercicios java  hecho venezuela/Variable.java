/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package variable;

import java.util.Scanner;

/**
 *
 * @author alexis094
 */
public class Variable {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Scanner sc=new Scanner (System.in);
        
        int n1,n2;
        
        System.out.println("selecciona un numero:");
        
        n1=sc.nextInt();
        System.out.println("selecciona otro numero:");
        n2=sc.nextInt();
        System.out.println("resultado total es:"+n1*n2);
    }
    
}
