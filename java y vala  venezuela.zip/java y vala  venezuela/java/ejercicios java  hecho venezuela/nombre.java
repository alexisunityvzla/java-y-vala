package nombre{

    public class nombre{

        public static void Main(string [] args){
            Scanner sc = new Scanner(System.in);

            string NOMBRE;
            System.out.println("Ingrese tu nombre:");
            NOMBRE= sc.nextstring();
            if(NOMBRE == "alexis"){
                System.out.println();
                System.out.println("hola");
            }
            else{
                System.out.println();
                System.out.println("no te conozco");
            }
            System.out.println("pulsa la tecla");
        }
    }
}