/*
 * bloque.java
 * 
 * Copyright 2017 alexiskayro <alexiskayro@alexiskayro-Intel-powered-classmate-PC>
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301, USA.
 * 
 * 
 */


public class bloque {
	
	public static void main (String[] args) {
		
		Scanner sc= new Scanner(System.in);
		
		int encimap,mapcar;
		int car,member;
		
		System.out.println("instroduzca la definicion del bloque :\n");
		System.out.println("instroduzca el primer bloque:\n");
		encimap=sc.nextInt();
		System.out.println("instroduzca el segundo bloque:\n");
		mapcar=sc.nextInt();
		if((encimap < 7.08)||(mapcar > 8.09)){
			
			encimap=encimap+1;
			mapcar=mapcar+2;
			
			}
			else{
				member=member+1;
				car=car+2;
				encimap=mapcar/member;
				
				
				}
				for(member=1;member<=2;member++){
				System.out.println("instroduzca el ultimo bloque:\n");
				car=sc.nextInt();
				System.out.println("el resultado del bloque es:\n"+car);
				
			}
			System.out.println("el primer resultado es:\n"+encimap);
			System.out.println("el segundo resultado es:\n"+mapcar);
			System.out.println("el ultimo resultado es:\n"+member);
			System.out.println("finalizar\n");
				
		
	}
}

