package materia{

    public class matematica{

        public double resultado;
        for(resultado=n;n>1;n==)
        return resultado;
    }
    public static void main(string args []){

        matematica m1=new matematica();
        double x=m1.factorial(25);
    }
}