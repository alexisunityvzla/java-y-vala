package variable{

    public class variable{

        public static void main (string args []){
		Scanner = new Scanner(System.in);
            int sum,restar,multi,div;

            sum=int.BufferEntrada.readLine("selecciona un numero");
            restar=sc.nextInt("selecciona otro numero");
            multi=sc.nextInt();
            div=sc.nextInt();

            sum=restar+multi;
            restar=multi-div;
            multi=sum*restar;
            div=multi/div;

            System.out.println("el resultado de la suma:",+sum);
            System.out.println("el resultado de la restar:",restar);
            System.out.println("el resultado de la multiplicacion:",+multi);
            System.out.println("el resultado de la division:",+div);
            System.out.println("finalizar");
            
        }
    }
}