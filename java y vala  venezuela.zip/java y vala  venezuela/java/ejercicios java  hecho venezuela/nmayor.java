package mayor{

    public class mayor{

        public static void Main(string [] args){
            Scanner sc = new Scanner (System.in);

            int num1,num2;

            System.out.println("numero 1:");
            num1= sc.nextINT();
            System.out.println("numero 2:");
            num2= sc.nextINT();
            if(num1 > num2){

                System.out.println(num1+"es mayor a que"+num2);
            }
            else{
                if(num1 == num2){

                    System.out.println(num1+"es igual"+num2);
                }
                else{
                    System.out.println(num1+"es menor a que"+num2);
                }
            }
            System.out.println("");
            System.out.println("otra manera");
            if(num1 > num2){
                RESUL="mayor";
            }
            else{
                if(num1 == num2){
                    RESUL="igual";
                }
                else{
                    RESUL="menor";
                }
            }

            System.out.println("es resultado es:"+num1+RESUL+num2);
            System.out.println("finalizar");
            
        }
    }
}