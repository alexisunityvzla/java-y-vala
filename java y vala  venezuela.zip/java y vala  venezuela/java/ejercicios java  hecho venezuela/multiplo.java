package multiplo{

    public class multiplo{

        public static void Main(string [] args){
		Scanner = new Scanner(System.in);
            int n1,n2;

            n1=sc.nextInt("introduzca un numero:");
            n2=sc.nextInt("instroduzca otro numero:");

            if(n1%n2==0){
                System.out.println("son multiplo");

            }
            else{
                System.out.println("no son multiplo");
            }
        }
    }
}