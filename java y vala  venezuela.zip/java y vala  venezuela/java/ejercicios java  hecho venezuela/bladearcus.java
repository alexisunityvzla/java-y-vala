

    public class bladearcus{

        public static void main (string args){
		Scanner = new Scanner(System.in);
           
            int opcion;

            System.out.println("selecciona tu personaje favoritos");
            opcion=sc.nextInt();
            System.out.println("blade arcus");
            switch(opcion){
                case 1: System.out.println("pairon"); break;
                case 2: System.out.println("sonia"); break;
                case 3: System.out.println("mystic"); break;
                case 4: System.out.println("ryuha"); break;
                case 5: System.out.println("rick"); break;
                case 6: System.out.println("rage"); break;
                case 7: System.out.println("urayukihime"); break;
                case 8: System.out.println("dylan"); break;
                case 9: default: System.out.println("esto son tu personajes favoritos"); break;
            }
        }
    }

