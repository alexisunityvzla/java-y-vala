/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nota;

import java.util.Scanner;

/**
 *
 * @author alexis094
 */
public class Nota {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner sc=new Scanner (System.in);
        
        int nota;
        System.out.println("digita la nota del estudiante:");
        
        nota=sc.nextInt();
        if(nota>12.09){
             System.out.println("eres excelente");
        
        }
        else{
        
        System.out.println("no eres excelente");
        }
        System.out.println("finalizar");
    }
    
}
