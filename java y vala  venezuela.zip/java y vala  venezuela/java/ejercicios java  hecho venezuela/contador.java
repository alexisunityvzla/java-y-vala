package contador{
	
	public class contador{

	    public class static void main(string [] args){

	     int cc,cd;
	     for(cc=5;cc<=1005;cc++){
	     cc=cc+5;
	     cd=cd-5;
	     System.out.println("numero_c es:"+cc+"numero_d es:"+cd);
	     

	     }
	  }
	}
}