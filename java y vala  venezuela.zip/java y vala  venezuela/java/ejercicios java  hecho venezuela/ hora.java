package hora{
	
	public class hora{

	   	public static void Main(string [] args){

	  	 	BufferedReader bufEntrada = new BuffereadReader(Input stream(System.in));

	   		int h,m,s;

	   		System.out.println("instroduzca hora:");
	   		h=bufEntrada.readLine();
	   		System.out.println("instroduzca minutos:");
	   		m=bufEtrada.readLine();
	   		System.out.println("instroduzca segundo:");
	   		s=bufEntrada.readLine();

	   		if(s >= 60){

	   		   s=0;
	   		   s++;
	   		   	if( m>= 60){

	   				m=0;
	   				m++;

	   				if(h >= 24){

	   				  h=0;

	   		   		}	
	   			
	   				else{

	   					System.out.println("Fecha:"+h+":"+m+":"+s+":");
	   			}	}
	   		}
	   		
	   	}
	}
}