package impar{

    public class{

        public static void main(string args []){
		Scanner = new Scanner(System.in);
            int n2,n3;
            System.out.println("coloca un numero mayor o menor:");
            System.out.println("selecciona un numero:");

            n2=sc.nextInt();

            System.out.println("selecciona otro numero:");

            n3=sc.nextInt();

            if(n3>n2){

                System.out.println("el numero mayor es:"+n3);
            }
            else{
                System.out.println("el numero menor es:"+n2);
            }
            System.out.println("finalizar");
        }
        
    }
}