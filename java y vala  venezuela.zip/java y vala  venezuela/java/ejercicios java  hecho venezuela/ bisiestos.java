package bisiestos{
	
	public class bisiestos{

	   public class static void Main(string [] args){

	      BufferedReader bufEntrada = new BufferedReader(InputStream(System.in));

	      	int dia,mes,año;

	      System.out.println("instroduzca dia:");
	      dia=bufEntrada.readLine();
	      System.out.println("instroduzca mes:");
	      mes=bufEntrada.readLine();
	      System.out.println("instroduzca año:");
	      año=bufEntrada.readLine();

	      	if(año == 0){
	        	System.out.println("fecha incorrecta");
	      	}
	      	else{

	      		if(mes==2 && dia >=1 && dia <= 28){

	      	  		System.out.println(dia+"/"+mes+"/"+año+": fecha incorrecta");
	      		}
	      		else{

	      	  		if((mes==4 || mes==6 || mes==9 || mes==11)&& (dia >=1 && dia<=30)){

	      	  	 		System.out.println(dia+"/"+mes+"/"+año+": fecha correcta");
	      	  		}
	      	  			
	      	  		else{

	      	     		if((mes==1 || mes==3 || mes==5 || mes==7 || mes== 8 || mes== 10 || mes== 12) && (dia >=1 && dia <=31)){

	      	     			System.out.println(dia+"/"+mes+"/"+año+": fecha correcta");
	      	     
	      	     		}
	      	     		else{
	      	       			
	      	       			System.out.println("fecha incorrecta");
	      	     		}
	      	 	 	}
	      		}
	     	}

	   }
	}
}
