package pares{
import.java.util.*;
  public class pares{

  public static void main(string [] args){
Scanner sc=new Scanner(System.in);

int N;

System.out.println("instroduzca un numero entero:");

N = sc.nextInt();

if(N%2==0){

  System.out.println("par");
}
else{
System.out.println("impar");
}


}
}
}
