package molecula{

    public molecula{
        static void Main(string [] args){
                Scanner = new Scanner(System.in);
            int h2o,nh3,ch4;

            System.out.println("la teoria de lewis");
            System.out.println("¿la cual se plantea  que los Atomos en un enlaces quimicos:");
            System.out.println("selecciona numero de molecula de agua:");

            h20=sc.nextInt()

            if(h2o<=99.09){

                System.out.println("el agua es equivalente a 92.08% en la tierra");
            }
            else{
                Sys.out.println("el agua no es equivalente a 92.08% en la tierra");
            }

            System.out.println("selecciona otro numero de molecula en la teoria de lewis:");
            System.out.println("selecciona numero de molecula de amoniacos:");

            nh3=sc.nextInt();

            if(nh3 <= 55){

                System.out.println("el nitrogeno es equivalente a 100% en la tierra");
            }
            else{

                System.out.println("el nitrogeno no es equivalente a 100% en la tierra");
            }

            System.out.println("selecciona el ultimo numero de molecula de la teoria de lewis");
            System.ou.println("selecciona numero molecula de metano");
            ch4=sc.nextInt();

            if(ch4 == 4){

                System.out.println("el nidrogeno es equivalente a 82.09% en la tierra");
            }
            else{
                System.out.println("el nidrogeno no es equivalente a 82.09% en la tierra);
            }

            System.out.println("la teoria de lewis:");
            System.out.println("total del agua es:"+h2o*92+10.15);
            System.out.println("el total del aire es:"+nh3+103*1986);
            System.out.println("el total de amoniacos es:"+ch4+1899/33+200);
            System.out.println("finalizar");
        }
    }
}